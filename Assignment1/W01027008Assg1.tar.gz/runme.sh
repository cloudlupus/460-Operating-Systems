#!/bin/bash
#David Shagam
#Operating Systems 460
#Run me for getting all outputs

make
./SCHEDULER 2 > ULE.txt
./SCHEDULER 16 > 4BSD.txt